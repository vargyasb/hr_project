package hu.webuni.hr.vargyasb.service;

import hu.webuni.hr.vargyasb.model.Employee;

public interface EmployeeService {
	int getPayRaisePercent(Employee employee);
}
